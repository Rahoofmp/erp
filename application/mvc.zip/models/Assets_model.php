<?php  defined('BASEPATH') OR exit('No direct script access allowed');

class Assets_model extends Base_model {

	function __construct() {
		parent::__construct();

	}

}